﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GrabPickups : MonoBehaviour {

	private AudioSource pickupSoundSource;

	// we start on the first floor
	public static int floorNumber = 1;
	public Text floorNumberDisplay;

	void Awake() {
		pickupSoundSource = DontDestroy.instance.GetComponents<AudioSource>()[1];
		// build the text that shows on the HUD
		floorNumberDisplay.text = "Floor " + floorNumber;
	}

	void OnControllerColliderHit(ControllerColliderHit hit) {
		if (hit.gameObject.tag == "Pickup") {
			pickupSoundSource.Play();
			// go to the next floor
			floorNumber++;
			SceneManager.LoadScene("Play");
		}
	}
}
