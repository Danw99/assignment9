using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FallInHole : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // if the character falls through a hole, stop the music
        // and go to the Game Over screen
        if (gameObject.transform.position.y < 0)
        {
            Destroy(GameObject.Find("WhisperSource"));
            // reset our character back to the first floor
            GrabPickups.floorNumber = 1;
            SceneManager.LoadScene("GameOver");
        }
    }
}
